# Date: 09/16/19
# Title: Mapping code using ggplot2
# Author: Paul Vetillard
#####################################
# Edited Mapping to Clean grey areas 
# By: Kara Rosas 
# Date: 09/18/19 

# load libraries
library(ggplot2)
library(sf)
library(sp)
library(readxl)
library(broom)
library(RColorBrewer)
library(dplyr)

# code to use fortify function
library(rgdal)
library(maptools)
if (!require(gpclib)) install.packages("gpclib", type="source")
gpclibPermit()


##### DATA ####

#shapefile data can be download on https://gadm.org/ 
#we will use the most precise Philippines shapefile data here: gadm36_PHL_3_sp.rds
#we will map poverty incidence in the Philipines thanks to PSA data


#### PREPARING SP DATA ####

# read data into a SpatialPolygonsDataFrame object
ph.map <- readRDS("/Volumes/GoogleDrive/My Drive/ICM Research/0.Data/6.Mapping/Mapping with ggplot2 - Paul/gadm36_PHL_3_sp.rds")
# add to data a new column termed "id" composed of the rownames of data
ph.map@data$id <- rownames(ph.map@data)
# create a data.frame from our spatial object
ph.df <- fortify(ph.map, region = "id")
# merge the "fortified" data with the data from our spatial object
ph.data <- merge(ph.df, ph.map@data, by = "id")
# create localisation columns in upper case to be able to merge sp data with psa data easily
ph.data$Province<-toupper(ph.data$NAME_1)
ph.data$City<-toupper(ph.data$NAME_2)
ph.data$Barangay<-toupper(ph.data$NAME_3)

#### PREPARING PSA DATA ####

#import
psa.data <- read.csv("/Volumes/GoogleDrive/My Drive/ICM Research/0.Data/6.Mapping/Mapping with ggplot2 - Paul/psa.data.csv", stringsAsFactors = F)
# these data have cleaned in another code to make it more tidy.
# we have 3 columns: Region, City and pov2015.
# we will plot at the municipality scale in this example, that's why we won't use Barangay in the data fusion.
# pov2015 represents the continuous variable that we will map. If this variable was discrete, we would need to 
# transform it into factors to create the different categories to map.

#objective: 
#we want to add the pov2015 column in ph.data.
# we will merge the two datasets on Region and City (not barangay in this case)
# because a city is represented by many different lines in ph.data (represented by a polygon), we must add pov2015
# to all the lines representing the city.

# psa.data: some cleaning
# sometimes region and city (and barangay but no used here) are not encoded the same way in both datasets.
# Here are some cleaning (not all) in order to have a cleaner map (ie less NA parts in grey)

psa.data$Region[psa.data$Region=="DAVAO OCCIDENTAL"] <- "DAVAO DEL SUR"
psa.data$City[psa.data$City=="JOSE ABAD SANTOS (TRINIDAD)"] <- "JOSE ABAD SANTOS"
psa.data$Region[psa.data$City=="JOSE ABAD SANTOS"] <- "DAVAO DEL SUR"
psa.data$Region[psa.data$City=="MALITA"] <- "DAVAO DEL SUR"
psa.data$Region[psa.data$City=="DON MARCELINO"] <- "DAVAO DEL SUR"
psa.data$Region[psa.data$City=="SANTA MARIA" & psa.data$pov2015=="55.04"] <- "DAVAO DEL SUR"
psa.data$Region[psa.data$City=="SARANGANI"] <- "DAVAO DEL SUR"
psa.data$City[psa.data$City=="MABINI (DOÑA ALICIA)"] <- "MABINI"
psa.data$City[psa.data$City=="MARAGUSAN (SAN MARIANO)"] <- "MARAGUSAN"
psa.data$City[psa.data$City=="ISLAND GARDEN CITY OF SAMAL"] <- "SAMAL CITY"
psa.data$City[psa.data$City=="MATI CITY (CAPITAL)"] <- "MATI CITY"
psa.data$City[psa.data$City=="LAAK (SAN VICENTE)"] <- "LAAK"
psa.data$City[psa.data$City=="ASUNCION (SAUG)"] <- "ASUNCION"
psa.data$City[psa.data$City=="DATU ODIN SINSUAT (DINAIG)"] <- "DATU ODIN SINSUAT"
psa.data$City[psa.data$City=="SULTAN KUDARAT (NULING)"] <- "SULTAN KUDARAT"
psa.data$City[psa.data$City=="PICONG (SULTAN GUMANDER)"] <- "PICONG"
psa.data$City[psa.data$City=="PAGAYAWAN (TATARIKAN)"] <- "PAGAYAWAN"
psa.data$City[psa.data$City=="LUMBA-BAYABAO (MAGUING)"] <- "LUMBA-BAYABAO"
psa.data$City[psa.data$City=="KORONODAL CITY"] <- "KORONADAL CITY"
psa.data$City[psa.data$City=="LIBJO (ALBOR)"] <- "LIBJO"
psa.data$City[psa.data$City=="BASILISA (RIZAL)"] <- "BASILISA"
psa.data$City[psa.data$City=="SANTA MONICA (SAPAO)"] <- "SANTA MONICA"
psa.data$City[psa.data$City=="SAN FRANCISCO (ANAO-AON)"] <- "SAN FRANCISCO"
psa.data$Region[psa.data$Region=="SAMAR (WESTERN)"] <- "SAMAR"
psa.data$City[psa.data$City=="CALANASAN (BAYAG)"] <- "CALANASAN"
psa.data$City[psa.data$City=="LICUAN-BAAY (LICUAN)"] <- "LICUAN-BAAY"
psa.data$City[psa.data$City=="RIZAL (LIWAN)"] <- "RIZAL"
psa.data$City[psa.data$City=="ALFONSO LISTA (POTIA)"] <- "ALFONSO LISTA"
psa.data$City[psa.data$City=="ILAGAN CITY"] <- "ILAGAN"
psa.data$City[psa.data$City=="COBARRONGUIS"] <- "CABARROGUIS"
psa.data$City[psa.data$City=="DIVILICAN"] <- "DIVILACAN"
psa.data$City[psa.data$City=="POZORRUBIO"] <- "POZZORUBIO"
psa.data$City[psa.data$City=="MABALACAT CITY"] <- "MABALACAT"
psa.data$Region[psa.data$Region=="4TH DISTRICT"] <- "METROPOLITAN MANILA"
psa.data$Region[psa.data$Region=="3RD DISTRICT"] <- "METROPOLITAN MANILA"
psa.data$Region[psa.data$Region=="2ND DISTRICT"] <- "METROPOLITAN MANILA"
psa.data$City[psa.data$City=="MUNTINLUPA CITY"] <- "MUNTINLUPA"
psa.data$City[psa.data$City=="CALOOCAN CITY"] <- "KALOOKAN CITY"
psa.data$City[psa.data$City=="SAN FRANCISCO (AURORA)"] <- "SAN FRANCISCO"
psa.data$City[psa.data$City=="SOFRONIO ESPAÑOLA"] <- "SOFRONIO ESPANOLA"
psa.data$City[psa.data$City=="SAGÑAY"] <- "SAGNAY"
psa.data$City[psa.data$City=="DARAGA (LOCSIN)"] <- "DARAGA"
psa.data$City[psa.data$City=="PARANAS (WRIGHT)"] <- "PARANAS"
psa.data$City[psa.data$City=="SANTO NIÑO"] <- "SANTO NINO"
psa.data$City[psa.data$City=="BELIZON"] <- "BELISON"
psa.data$City[psa.data$City=="DUEÑAS"] <- "DUENAS"
psa.data$City[psa.data$City=="MOISES PADILLA (MAGALLON)"] <- "MOISES PADILLA"
psa.data$City[psa.data$City=="HINOBA-AN (ASIA)"] <- "HINOBA-AN"
psa.data$City[psa.data$City=="CARCAR CITY"] <- "CARCAR"
psa.data$City[psa.data$City=="GETAFE"] <- "JETAFE"
psa.data$City[psa.data$City=="ALBURQUERQUE"] <- "ALBUQUERQUE"
psa.data$City[psa.data$City=="SAN JUAN (CABALIAN)"] <- "SAN JUAN"
psa.data$City[psa.data$City=="HINUNANGAN"] <- "HINUNANGAN"
psa.data$City[psa.data$City=="JAVIER (BUGHO)"] <- "JAVIER"
psa.data$City[psa.data$City=="BALINDONG (WATU)"] <- "BALINDONG"
psa.data$City[psa.data$City=="BACOLOD-KALAWI"] <- "BACOLOD KALAWI"
psa.data$City[psa.data$City=="POONA BAYABAO (GATA)"] <- "POONA BAYABAO"
psa.data$City[psa.data$City=="LUMBACA-UNAYAN"] <- "LUMBACA UNAYAN"
psa.data$City[psa.data$City=="PANGLIMA ESTINO (NEW PANAMAO)"] <- "PANGLIMA ESTINO"
psa.data$City[psa.data$City=="HADJI PANGLIMA TAHIL (MARUNGGAS)"] <- "HADJI PANGLIMA TAHIL"
psa.data$City[psa.data$City=="PANGLIMA SUGALA (BALIMBING)"] <- "PANGLIMA SUGALA"
psa.data$City[psa.data$City=="MAPUN (CAGAYAN DE TAWI-TAWI)"] <- "MAPUN"
psa.data$City[psa.data$City=="BACUNGAN (LEON T. POSTIGO)"] <- "BACUNGAN"
psa.data$City[psa.data$City=="JOSE DALMAN (PONOT)"] <- "JOSE DALMAN"
psa.data$City[psa.data$City=="SERGIO OSMEÑA SR."] <- "SERGIO OSMENA SR."
psa.data$City[psa.data$City=="PIÑAN"] <- "PINAN"
psa.data$City[psa.data$City=="DATU ABDULLAH SANGKI"] <- "DATU ABDULLAH SANKI"
psa.data$City[psa.data$City=="SULTAN SA BARONGIS (LAMBAYONG)"] <- "SULTAN SA BARONGIS"
psa.data$City[psa.data$City=="SHARIFF AGUAK (MAGANOY)"] <- "SHARIFF AGUAK"
ph.data$City[ph.data$City=="SANTO NIÑO"] <- "SANTO NINO"
psa.data$City[psa.data$City=="PARAÑAQUE CITY"] <- "PARAÑAQUE"
psa.data$City[psa.data$City=="TAGUIG CITY"] <- "TAGUIG"
psa.data$City[psa.data$City=="SAN IDELFONSO"] <- "SAN ILDEFONSO"
psa.data$City[psa.data$City=="RODRIGUEZ (MONTALBAN)"] <- "RODRIGUEZ"
psa.data$City[psa.data$City=="NAVOTAS CITY"] <- "NAVOTAS"
psa.data$City[psa.data$City=="MALABON CITY"] <- "MALABON"

psa.data$City[psa.data$City=="VALENZUELA  CITY"] <- "VALENZUELA"
psa.data$City[psa.data$City=="MANDALUYONG  CITY"] <- "MANDALUYONG"
psa.data$City[psa.data$City=="MARIKINA  CITY"] <- "MARIKINA"
psa.data$City[psa.data$City=="SAN JUAN  CITY"] <- "SAN JUAN"
psa.data$City[psa.data$City=="NAVOTAS  CITY"] <- "NAVOTAS"
psa.data$City[psa.data$City=="LAS PIÑAS  CITY"] <- "LAS PIÑAS"
psa.data$City[psa.data$City=="MUNTINLUPA  CITY"] <- "MUNTINLUPA"
psa.data$City[psa.data$City=="PARAÑAQUE  CITY"] <- "PARAÑAQUE"
psa.data$City[psa.data$City=="TAGUIG  CITY"] <- "TAGUIG"
psa.data$City[psa.data$City=="MAKATI  CITY"] <- "MAKATI CITY"
psa.data$City[psa.data$City=="BACOOR CITY"] <- "BACOOR"
psa.data$City[psa.data$City=="DASMARIÑAS CITY"] <- "DASMARIÑAS"
psa.data$City[psa.data$City=="GENERAL TRIAS CITY"] <- "GENERAL TRIAS"
psa.data$City[psa.data$City=="SAN PEDRO CITY"] <- "SAN PEDRO"
psa.data$City[psa.data$City=="BIÑAN CITY"] <- "BIÑAN"
psa.data$City[psa.data$City=="MENDEZ (MENDEZ-NUÑEZ)"] <- "MENDEZ"
psa.data$City[psa.data$City=="GEN. MARIANO ALVAREZ"] <- "GENERAL MARIANO ALVAREZ"
psa.data$City[psa.data$City=="CABUYAO CITY"] <- "CABUYAO"



# Merging Missing Povscores 
# Manila, Isabela City, Cotabato City 
psa.data.add <- read.csv("/Volumes/GoogleDrive/My Drive/ICM Research/0.Data/6.Mapping/Mapping with ggplot2 - Paul/additional povscore.csv", stringsAsFactors = F)
psa.data <- rbind(psa.data, psa.data.add)

# Merge of the two datasets
data.merge <- merge(ph.data, psa.data, by.x=c("Province", "City"),
                    by.y=c("Region", "City"), all.x=T)

# Here is a way to select a part of the map (here Mindanao) instead of the all.
# We just need to filter the dataset thanks to a column (many can be used).

# data.merge <- data.merge %>% filter(NAME_1 %in% c("Dinagat Islands", "Surigao del Norte", "Surigao del Sur",
#                                                       "Agusan del Norte", "Misamis Oriental", "Camiguin", "Lanao del Norte",
#                                                       "Misamis Occidental", "Zamboanga del Norte", "Zamboanga Sibugay",
#                                                       "Tawi-Tawi", "Sulu", "Basilan", "Zamboanga del Sur", "Lanao del Sur",
#                                                       "Bukidnon", "Agusan del Sur", "Davao Oriental", "Compostela Valley",
#                                                       "Davao del Norte", "Davao del Sur", "North Cotabato", "Maguindanao",
#                                                       "Sultan Kudarat", "South Cotabato", "Sarangani"))

#### VERY IMPORTANT - ORDER ####

# because we manipulated the datasets, lines order have change. 
# We need to reorder them to have a clean and well plotted map!
data.merge <- data.merge[order(data.merge$order),]

#### ggplot - Mapping ####
# Red Version 
pdf(file="/Users/kara/Desktop/ICM/map.test.red.pdf")
ggplot() +                                               # initialize ggplot object
  geom_polygon(                                          # make a polygon
    data = data.merge,                                   # data frame
    aes(x = long, y = lat, group = group,                # coordinates, and group them by polygons
        fill = pov2015)) +                               # fill the polygons depending on pov2015
  labs(fill="Poverty incidence \n(in % of the population)", size=8) + # title and size of the legend
  scale_fill_gradient(low="#FAE1A4", high="#EE2D38",     # two colours for the extremities of the scale
                      breaks=c(0,20,40,60,80),           # breaks in the scale
                      labels = c("0%", "20%", "40%", "60%", "80%"),
                      na.value = "white") +  #breaks labels
  ggtitle("Poverty incidence - PSA 2015") +                         # add title to the map
  theme(panel.background = element_blank(),            # remove axis lines ..
        axis.text=element_blank(),                     # .. tickmarks..
        axis.title=element_blank(),                    # .. axis labels..
        line = element_blank()) +                      # .. background gridlines
  theme(legend.position = "bottom", legend.title = element_text(size = 8, hjust = 0.5), # legend characteristics
        plot.title = element_text(size = 14, face = "bold", hjust = 0.5)) +  # map title characteristics
  coord_equal()      # both axes the same scale
dev.off()

# Blue Version
pdf(file="/Users/kara/Desktop/ICM/map.test.blue.pdf")
ggplot() +                                               # initialize ggplot object
  geom_polygon(                                          # make a polygon
    data = data.merge,                                   # data frame
    aes(x = long, y = lat, group = group,                # coordinates, and group them by polygons
        fill = pov2015)) +                               # fill the polygons depending on pov2015
  labs(fill="Poverty incidence \n(in % of the population)", size=8) + # title and size of the legend
  scale_fill_gradient(low="#8BABAF", high="#004750",     # two colours for the extremities of the scale
                      breaks=c(0,20,40,60,80),           # breaks in the scale
                      labels = c("0%", "20%", "40%", "60%", "80%")) +  #breaks labels
  ggtitle("Poverty incidence - PSA 2015") +                         # add title to the map
  theme(panel.background = element_blank(),            # remove axis lines ..
        axis.text=element_blank(),                     # .. tickmarks..
        axis.title=element_blank(),                    # .. axis labels..
        line = element_blank()) +                      # .. background gridlines
  theme(legend.position = "bottom", legend.title = element_text(size = 8, hjust = 0.5), # legend characteristics
        plot.title = element_text(size = 14, face = "bold", hjust = 0.5)) +  # map title characteristics
  coord_equal()      # both axes the same scale
dev.off()


#Green Version 
pdf(file="/Users/kara/Desktop/ICM/map.test.green.pdf")
ggplot() +                                               # initialize ggplot object
  geom_polygon(                                          # make a polygon
    data = data.merge,                                   # data frame
    aes(x = long, y = lat, group = group,                # coordinates, and group them by polygons
        fill = pov2015)) +                               # fill the polygons depending on pov2015
  labs(fill="Poverty incidence \n(in % of the population)", size=8) + # title and size of the legend
  scale_fill_gradient(low="#A3C196", high="#578F40",     # two colours for the extremities of the scale
                      breaks=c(0,20,40,60,80),           # breaks in the scale
                      labels = c("0%", "20%", "40%", "60%", "80%")) +  #breaks labels
  ggtitle("Poverty incidence - PSA 2015") +                         # add title to the map
  theme(panel.background = element_blank(),            # remove axis lines ..
        axis.text=element_blank(),                     # .. tickmarks..
        axis.title=element_blank(),                    # .. axis labels..
        line = element_blank()) +                      # .. background gridlines
  theme(legend.position = "bottom", legend.title = element_text(size = 8, hjust = 0.5), # legend characteristics
        plot.title = element_text(size = 14, face = "bold", hjust = 0.5)) +  # map title characteristics
  coord_equal()      # both axes the same scale
dev.off()
