# Date: 09/16/19
# Title: Mapping code using ggplot2
# Author: Paul Vetillard
#####################################
# Edited Mapping to Clean grey areas 
# By: Kara Rosas 
# Date: 09/18/19 
######################################
# Used Paul / Kara's base code to create code to map prevail groups by barangay / region?
# By: Joy Kimmel
# Date: 11/07/2019

### TO PLOT THIS FILE REQUIRES SNAPSHOT DATA REMOVED FROM THE SCRIPT.

# load libraries
library(ggplot2)
library(sf)
library(sp)
library(readxl)
library(broom)
library(RColorBrewer)
library(dplyr)
library(rgeos)
library(rgdal)

# install.packages('rgeos', type='source')
# install.packages('rgdal', type='source')

# code to use fortify function
library(rgdal)
library(maptools)
library(gpclib)
if (!require(gpclib)) install.packages("gpclib", type="source")
gpclibPermit()

##### DATA ####
# DOWNLOAD: PHILIPPINES LEVEL 3 SP DATA FROM 
# shapefile data can be download on https://gadm.org/download_country_v3.html
# we will use the most precise Philippines shapefile data here: gadm36_PHL_3_sp.rds

# CHANGE TO CURRENT DIRECTORY
ph.data.dir <- "~/Google Drive File Stream/My Drive/ICM Research/0. Data/6.Mapping/philippines_mapping_041020/"

#### PREPARING SP DATA ####
# read data into a SpatialPolygonsDataFrame object
ph.map <- readRDS(paste0(ph.data.dir, "gadm36_PHL_3_sp.rds"))
# add to data a new column termed "id" composed of the rownames of data
ph.map@data$id <- rownames(ph.map@data)
# create a data.frame from our spatial object
ph.df <- fortify(ph.map, region = "id")
# merge the "fortified" data with the data from our spatial object
ph.data <- merge(ph.df, ph.map@data, by = "id")

# create localisation columns in upper case to be able to merge sp data with psa data easily
ph.data$Province<-toupper(ph.data$NAME_1)
ph.data$City<-toupper(ph.data$NAME_2)
ph.data$Barangay<-toupper(ph.data$NAME_3)

## EXTRAT RAW DATA
ph.data.export <- ph.data %>% select(id, NAME_1, NAME_2, NAME_3, lat, long) %>% 
  rename(Province = NAME_1, 
         City = NAME_2, 
         Barangay = NAME_3,
         Latitude = lat,
         Logitude = long)

# ph.data.export.clean <- ph.data.export %>% filter(!duplicated(paste0(Province, City, Barangay)))
# ph.data.export.clean <- ph.data.export.clean %>% arrange(Province, City, Barangay)
# write.csv(ph.data.export.clean, paste0(ph.data, "new_locations.csv"), row.names=FALSE)

# Merge of the two datasets
# snap.map <- merge(ph.data, snap, by.x=c("Province", "City", "Barangay"),
#                                  by.y=c("province", "city", "barangay"), all.x=T)

snap.map <- merge(ph.data, snap, by.x=c("Province", "City"),
                                 by.y=c("province", "city"), all.x=T)

preload <- read.csv(paste0(snap.dir.raw, "Philippines_Preload.csv"), stringsAsFactors = F)
preload <- preload %>% select(-region)

#### VERY IMPORTANT - ORDER ####
# because we manipulated the datasets, lines order have change. 
# We need to reorder them to have a clean and well plotted map
snap.map <- snap.map %>% filter(Province %in% preload$province)
snap.map <- snap.map[order(snap.map$order),]

### NOTE THIS FILE WILL NOT WORK SINCE I HAVE REMOVED THE SNAPSHOT DATA REQUIRED TO RUN IT.

#### ggplot - Mapping ####
# Green Version 
map <- ggplot() +                                               # initialize ggplot object
  geom_polygon(                                          # make a polygon
    data = snap.map,                                     # data frame
    aes(x = long, y = lat, group = group,                # coordinates, and group them by polygons
        fill = cnt_total)) +                             # fill the polygons depending on pov2015
  labs(fill="Active Savings Groups", size=8) + # title and size of the legend
  scale_fill_gradient(low="#89CEBB", high="#004750",     # two colours for the extremities of the scale
                      breaks=c(0,10,20,30),           # breaks in the scale
                      labels = c("0", "10", "20", "30"),
                      na.value = "gray") +  #breaks labels
  # ggtitle("ICM 2019 Prevail Saturation") +             # add title to the map
  theme(panel.background = element_blank(),            # remove axis lines ..
        axis.text=element_blank(),                     # .. tickmarks..
        axis.title=element_blank(),                    # .. axis labels..
        line = element_blank()) +                      # .. background gridlines
  theme(legend.position = "bottom", legend.title = element_text(size = 7, hjust = 0.5), # legend characteristics
        plot.title = element_text(size = 14, face = "bold", hjust = 0.5)) +  # map title characteristics
  coord_equal()      # both axes the same scale
# dev.off()

ggsave(paste0(save.dir, "snapshot-city-03072020.pdf"), map)
ggsave(paste0(save.dir, "snapshot-city-03072020.png"), map)

# ggplotly_map <- ggplotly(map)